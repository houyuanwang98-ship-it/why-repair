#!/usr/bin/env python3
"""Run 24 gpt-5.6-sol/xhigh servers paired with 24 gpt-6/high servers."""
import argparse
import fcntl
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from harness.workflow_v2.experiment import preflight
from harness.workflow_v2.scheduler import Scheduler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--experiment-only", action="store_true",
                        help="Start only 24 gpt-5.6-sol servers; freeze every candidate and defer judging")
    args = parser.parse_args()
    with (args.bundle / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        checked = preflight(args.bundle)
        if not args.execute:
            print(json.dumps({"preflight": checked, "servers": {"gpt-5.6-sol/xhigh": 24,
                "gpt-6/high": 0 if args.experiment_only else 24},
                "new_model_calls": 0, "start_requires": "--execute"}, ensure_ascii=False, indent=2))
            return
        result = Scheduler(args.bundle, mode="experiment_only" if args.experiment_only else "pipeline").run()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if result["status"] not in {"completed", "completed_with_failures"}:
            sys.exit(1)


if __name__ == "__main__":
    main()
